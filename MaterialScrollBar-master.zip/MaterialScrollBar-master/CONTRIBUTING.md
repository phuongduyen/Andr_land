Feel free to contribute in any way you'd like.

To keep things internally consistent, please stick to US English spellings. Depending on which is easiest for you, we can communicate in English, French, or German as necessary.
