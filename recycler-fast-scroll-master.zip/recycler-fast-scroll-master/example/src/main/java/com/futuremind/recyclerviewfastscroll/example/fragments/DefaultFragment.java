package com.futuremind.recyclerviewfastscroll.example.fragments;

import com.futuremind.recyclerviewfastscroll.example.R;


public class DefaultFragment extends ExampleFragment {

    @Override
    public int getLayoutId() {
        return R.layout.fragment_default;
    }
}
